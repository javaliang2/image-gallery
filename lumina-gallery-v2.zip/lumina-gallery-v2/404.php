<?php get_header(); ?>

<div style="padding:100px 0;text-align:center;">
  <div class="container">
    <p style="font-size:6rem;font-family:var(--font-display);color:var(--accent);line-height:1;margin-bottom:16px;">404</p>
    <h1 style="margin-bottom:12px;"><?php esc_html_e( '页面未找到', 'lumina-gallery' ); ?></h1>
    <p style="color:var(--text-muted);margin-bottom:32px;"><?php esc_html_e( '您访问的页面不存在，可能已被删除或移动。', 'lumina-gallery' ); ?></p>
    <a href="<?php echo esc_url( home_url( '/' ) ); ?>" style="display:inline-flex;align-items:center;gap:8px;background:var(--accent);color:var(--bg);padding:12px 28px;border-radius:var(--radius);font-weight:600;font-size:.9rem;letter-spacing:.06em;text-decoration:none;">
      ← <?php esc_html_e( '返回首页', 'lumina-gallery' ); ?>
    </a>
    <div style="margin-top:56px;">
      <?php get_search_form(); ?>
    </div>
  </div>
</div>

<?php get_footer(); ?>
