<?php
/**
 * Template Part: Gallery Card
 * 点击封面/标题均跳转文章；悬停时右上角出现放大镜图标可打开 lightbox。
 */
$thumb_url = get_the_post_thumbnail_url( get_the_ID(), 'lumina-medium' );
$full_url  = get_the_post_thumbnail_url( get_the_ID(), 'full' );
$cats      = get_the_category();
$first_cat = $cats ? $cats[0] : null;
$tags      = get_the_tags();
?>

<?php if ( $thumb_url ) : ?>
<a href="<?php the_permalink(); ?>" class="card-thumb" aria-label="<?php the_title_attribute(); ?>">
  <img src="<?php echo esc_url( $thumb_url ); ?>"
       alt="<?php the_title_attribute(); ?>"
       loading="lazy"
       decoding="async">
  <!-- Lightbox 触发：仅打开大图，不跳转 -->
  <button class="card-zoom"
          data-src="<?php echo esc_url( $full_url ?: $thumb_url ); ?>"
          data-alt="<?php the_title_attribute(); ?>"
          aria-label="<?php esc_attr_e( '查看大图', 'lumina-gallery' ); ?>"
          type="button">
    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
      <circle cx="11" cy="11" r="8"/>
      <line x1="21" y1="21" x2="16.65" y2="16.65"/>
      <line x1="11" y1="8" x2="11" y2="14"/>
      <line x1="8" y1="11" x2="14" y2="11"/>
    </svg>
  </button>
  <div class="card-overlay" aria-hidden="true">
    <p class="overlay-title"><?php the_title(); ?></p>
  </div>
</a>
<?php else : ?>
<a href="<?php the_permalink(); ?>" class="card-thumb no-img" aria-label="<?php the_title_attribute(); ?>">
  <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
    <rect x="3" y="3" width="18" height="18" rx="2"/>
    <circle cx="8.5" cy="8.5" r="1.5"/>
    <polyline points="21 15 16 10 5 21"/>
  </svg>
</a>
<?php endif; ?>

<div class="card-body">
  <div class="card-meta">
    <?php if ( $first_cat ) : ?>
      <a href="<?php echo esc_url( get_category_link( $first_cat->term_id ) ); ?>" class="card-cat"><?php echo esc_html( $first_cat->name ); ?></a>
      <span class="card-dot"></span>
    <?php endif; ?>
    <time class="card-date" datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>"><?php echo esc_html( get_the_date() ); ?></time>
  </div>

  <h2 class="card-title">
    <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
  </h2>

  <?php if ( get_the_excerpt() ) : ?>
  <p class="card-excerpt"><?php echo wp_kses_post( get_the_excerpt() ); ?></p>
  <?php endif; ?>

  <?php if ( $tags ) : ?>
  <div class="card-tags">
    <?php foreach ( array_slice( $tags, 0, 3 ) as $tag ) : ?>
      <a href="<?php echo esc_url( get_tag_link( $tag ) ); ?>" class="card-tag">#<?php echo esc_html( $tag->name ); ?></a>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
</div>
