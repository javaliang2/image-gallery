# Lumina Gallery — WordPress 图片集主题

一款暗色系、专业级图片集 WordPress 主题。

## 功能特性

### 布局与视觉
- **响应式网格**：自适应 Masonry 瀑布流布局，桌面三列、平板两列、手机单列
- **视图切换**：网格 / 列表两种模式，偏好持久化
- **灯箱效果**：点击图片全屏浏览，支持键盘导航（← → Esc）
- **加载动画**：IntersectionObserver 驱动的卡片进场动画

### 导航与分类
- **主导航菜单**：支持多级下拉，移动端折叠收起
- **分类过滤栏**：置顶粘性栏，一键按分类筛选
- **标签云**：侧边栏标签云 widget，支持 album_tag 自定义分类
- **搜索**：全局搜索悬浮层，Ctrl+K 快捷键触发

### 分页
- **传统分页**：WP 标准 paginate_links 分页
- **Ajax 加载更多**：无刷新追加内容，自动判断是否还有更多

### 自定义后台
- **图片集 CPT**：`lumina_album` 自定义内容类型
- **图集分类 & 标签**：`album_category` / `album_tag` 自定义分类法
- **主题定制器**：社交链接、页脚文字、每页数量设置

### 性能与可访问性
- 懒加载图片（loading="lazy"）
- 字体 display=swap
- 键盘可聚焦 (:focus-visible)
- ARIA 标签与 role 属性
- 移除 WP emoji 脚本

## 安装方式

1. 将 `lumina-gallery` 文件夹压缩为 `.zip`
2. 进入 WordPress 后台 → 外观 → 主题 → 安装主题 → 上传主题
3. 激活主题
4. 外观 → 菜单 → 为 `主导航` 位置分配菜单
5. 外观 → 小工具 → 配置侧边栏与页脚

## 推荐图片尺寸

| 尺寸名称        | 像素              | 用途         |
|----------------|-------------------|-------------|
| lumina-thumb   | 600 × 450 (裁剪)  | 列表缩略图  |
| lumina-medium  | 900 × 680 (裁剪)  | 网格卡片    |
| lumina-hero    | 1400 × 780 (裁剪) | 单篇页头    |
| lumina-square  | 480 × 480 (裁剪)  | 侧边栏缩略 |

## 图集图片设置

在文章编辑界面，使用自定义字段 `_lumina_gallery_images`，  
值为逗号分隔的附件 ID 列表，例如：`123,456,789`

## 文件结构

```
lumina-gallery/
├── style.css              # 主样式 + 主题声明
├── functions.php          # 主题配置、CPT、Ajax
├── header.php             # 页头模板
├── footer.php             # 页尾模板
├── index.php              # 主循环（首页/归档/分类/标签/搜索）
├── single.php             # 单篇文章页
├── searchform.php         # 搜索表单
├── 404.php                # 404 页面
├── screenshot.png         # 主题截图（需手动添加）
├── template-parts/
│   └── card-gallery.php   # 图片卡片片段
├── js/
│   └── main.js            # 交互脚本
└── README.md              # 本文档
```

## 版权

GNU General Public License v2.0  
字体：Cormorant Garamond + DM Sans（Google Fonts，OFL 1.1）
