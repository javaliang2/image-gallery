/**
 * Lumina Gallery — main.js  v1.3
 * Hero slider + menu + search + lightbox + load-more + back-to-top
 * Fix: lightbox arrow keys in single post; improved image collection
 */
(function () {
  'use strict';

  document.addEventListener('DOMContentLoaded', function () {
    initHeroSlider();
    initMobileMenu();
    initSubMenuMobile();
    initSearchOverlay();
    initColToggle();
    initViewToggle();
    initLoadMore();
    initLightbox();
    initBackToTop();
    initCardAnimations();
  });

  /* ============================================================
     1. HERO SLIDER
     ============================================================ */
  function initHeroSlider() {
    var slider   = document.getElementById('heroSlider');
    if (!slider) return;

    var track    = document.getElementById('heroSlides');
    var dots     = document.querySelectorAll('.hero-dot');
    var thumbs   = document.querySelectorAll('.hero-thumb');
    var slides   = document.querySelectorAll('.hero-slide');
    var prev     = document.getElementById('heroPrev');
    var next     = document.getElementById('heroNext');
    var progress = document.getElementById('heroProgress');

    if (!track || slides.length < 2) return;

    var total    = slides.length;
    var current  = 0;
    var autoplayMs = parseInt(slider.getAttribute('data-autoplay') || '5000');
    var timer    = null;
    var progTimer = null;

    function goTo(idx) {
      idx = ((idx % total) + total) % total;
      slides[current].classList.remove('is-active');
      slides[idx].classList.add('is-active');
      track.style.transform = 'translateX(-' + (idx * 100) + '%)';
      dots.forEach(function(d, i) { d.classList.toggle('is-active', i === idx); });
      thumbs.forEach(function(t, i) { t.classList.toggle('is-active', i === idx); });
      current = idx;
      restartProgress();
    }

    function restartProgress() {
      if (!progress) return;
      clearInterval(progTimer);
      progress.style.transition = 'none';
      progress.style.width = '0%';
      void progress.offsetWidth;
      progress.style.transition = 'width ' + autoplayMs + 'ms linear';
      progress.style.width = '100%';
    }

    function startAutoplay() {
      clearInterval(timer);
      timer = setInterval(function () { goTo(current + 1); }, autoplayMs);
      restartProgress();
    }

    function stopAutoplay() {
      clearInterval(timer);
      clearInterval(progTimer);
      if (progress) { progress.style.transition = 'none'; progress.style.width = '0%'; }
    }

    if (prev) prev.addEventListener('click', function () { goTo(current - 1); startAutoplay(); });
    if (next) next.addEventListener('click', function () { goTo(current + 1); startAutoplay(); });

    dots.forEach(function(d) {
      d.addEventListener('click', function () { goTo(parseInt(d.getAttribute('data-index'))); startAutoplay(); });
    });

    thumbs.forEach(function(t) {
      t.addEventListener('click', function () { goTo(parseInt(t.getAttribute('data-index'))); startAutoplay(); });
    });

    var touchStartX = 0;
    slider.addEventListener('touchstart', function(e) { touchStartX = e.touches[0].clientX; }, { passive: true });
    slider.addEventListener('touchend', function(e) {
      var dx = e.changedTouches[0].clientX - touchStartX;
      if (Math.abs(dx) > 50) { goTo(current + (dx < 0 ? 1 : -1)); startAutoplay(); }
    }, { passive: true });

    slider.addEventListener('mouseenter', stopAutoplay);
    slider.addEventListener('mouseleave', startAutoplay);

    // 键盘：仅在 lightbox 未打开时响应
    document.addEventListener('keydown', function(e) {
      var lb = document.getElementById('lightboxModal');
      if (lb && lb.classList.contains('is-open')) return;
      if (e.key === 'ArrowLeft')  { goTo(current - 1); startAutoplay(); }
      if (e.key === 'ArrowRight') { goTo(current + 1); startAutoplay(); }
    });

    startAutoplay();
  }

  /* ============================================================
     2. MOBILE MENU
     ============================================================ */
  function initMobileMenu() {
    var toggle = document.getElementById('menuToggle');
    var nav    = document.getElementById('site-navigation');
    if (!toggle || !nav) return;

    toggle.addEventListener('click', function () {
      var open = nav.classList.toggle('is-open');
      toggle.classList.toggle('is-open', open);
      toggle.setAttribute('aria-expanded', String(open));
    });

    document.addEventListener('click', function (e) {
      if (!nav.contains(e.target) && !toggle.contains(e.target)) {
        nav.classList.remove('is-open');
        toggle.classList.remove('is-open');
        toggle.setAttribute('aria-expanded', 'false');
      }
    });
  }

  /* ============================================================
     3. SUB-MENU MOBILE
     ============================================================ */
  function initSubMenuMobile() {
    document.querySelectorAll('.menu-item-has-children > a').forEach(function (link) {
      link.addEventListener('click', function (e) {
        if (window.innerWidth > 768) return;
        e.preventDefault();
        link.parentElement.classList.toggle('sub-open');
      });
    });
  }

  /* ============================================================
     4. SEARCH OVERLAY
     ============================================================ */
  function initSearchOverlay() {
    var openBtn  = document.getElementById('searchToggle');
    var closeBtn = document.getElementById('searchClose');
    var overlay  = document.getElementById('searchOverlay');
    if (!overlay) return;

    function openSearch() {
      overlay.classList.add('is-open');
      var inp = overlay.querySelector('input[type="search"]');
      if (inp) setTimeout(function () { inp.focus(); }, 80);
    }
    function closeSearch() { overlay.classList.remove('is-open'); }

    if (openBtn)  openBtn.addEventListener('click', openSearch);
    if (closeBtn) closeBtn.addEventListener('click', closeSearch);
    overlay.addEventListener('click', function (e) { if (e.target === overlay) closeSearch(); });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') closeSearch();
      if ((e.ctrlKey || e.metaKey) && e.key === 'k') { e.preventDefault(); openSearch(); }
    });
  }

  /* ============================================================
     4b. COLUMN TOGGLE
     ============================================================ */
  function initColToggle() {
    var btns = document.querySelectorAll('.col-btn');
    var grid = document.getElementById('galleryGrid');
    if (!grid || !btns.length) return;

    var STORAGE_KEY = 'lumina_cols';
    var COL_MIN = { '2': '480px', '3': '320px', '4': '240px', '5': '190px' };

    function setGrid(cols) {
      // Apply via data attribute (CSS attribute selectors) for crisp override
      grid.setAttribute('data-cols', cols);
      btns.forEach(function(b) { b.classList.toggle('is-active', b.getAttribute('data-cols') === cols); });
      try { sessionStorage.setItem(STORAGE_KEY, cols); } catch(e) {}
    }

    btns.forEach(function(btn) {
      btn.addEventListener('click', function() {
        setGrid(btn.getAttribute('data-cols'));
      });
    });

    // Restore saved preference (falls back to CSS variable default)
    try {
      var saved = sessionStorage.getItem(STORAGE_KEY);
      if (saved && document.querySelector('.col-btn[data-cols="' + saved + '"]')) {
        setGrid(saved);
      } else {
        // Mark the active button matching the server-side default (already has is-active from PHP)
      }
    } catch(e) {}
  }

  /* ============================================================
     5. VIEW TOGGLE
     ============================================================ */
  function initViewToggle() {
    var btns = document.querySelectorAll('.view-btn');
    var grid = document.getElementById('galleryGrid');
    if (!grid) return;

    btns.forEach(function (btn) {
      btn.addEventListener('click', function () {
        btns.forEach(function (b) { b.classList.remove('is-active'); });
        btn.classList.add('is-active');
        grid.classList.toggle('view-list', btn.getAttribute('data-view') === 'list');
        try { sessionStorage.setItem('lumina_view', btn.getAttribute('data-view')); } catch(e) {}
      });
    });

    try {
      var saved = sessionStorage.getItem('lumina_view');
      if (saved) { var btn = document.querySelector('[data-view="' + saved + '"]'); if (btn) btn.click(); }
    } catch(e) {}
  }

  /* ============================================================
     6. AJAX LOAD MORE
     ============================================================ */
  function initLoadMore() {
    var btn  = document.getElementById('loadMoreBtn');
    var grid = document.getElementById('galleryGrid');
    if (!btn || !grid || typeof luminaData === 'undefined') return;

    var loading = false;

    btn.addEventListener('click', function () {
      if (loading) return;
      var page = parseInt(btn.getAttribute('data-page') || '1');
      var max  = parseInt(btn.getAttribute('data-max') || '1');
      if (page + 1 > max) { btn.textContent = luminaData.noMoreTxt; btn.disabled = true; return; }

      loading = true;
      var orig = btn.innerHTML;
      btn.innerHTML = '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="animation:spin 1s linear infinite"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg> ' + luminaData.loadingTxt;

      var fd = new FormData();
      fd.append('action',    'lumina_load_more');
      fd.append('nonce',     luminaData.nonce);
      fd.append('page',      page);
      fd.append('post_type', grid.getAttribute('data-post-type') || 'post');
      fd.append('per_page',  grid.getAttribute('data-per-page') || 12);

      fetch(luminaData.ajaxUrl, { method: 'POST', body: fd })
        .then(function(r) { return r.json(); })
        .then(function(data) {
          if (data.success && data.data.html) {
            var tmp = document.createElement('div');
            tmp.innerHTML = data.data.html;
            tmp.querySelectorAll('.gallery-card').forEach(function(card, i) {
              card.style.setProperty('--i', i + 1);
              card.classList.add('anim-fade-up');
              grid.appendChild(card);
            });
            btn.setAttribute('data-page', String(page + 1));
            btn.innerHTML = orig;
            if (!data.data.has_more || page + 1 >= max) { btn.textContent = luminaData.noMoreTxt; btn.disabled = true; }
            bindLightboxTriggers();
          } else { btn.textContent = luminaData.noMoreTxt; btn.disabled = true; }
        })
        .catch(function() { btn.innerHTML = orig; })
        .finally(function() { loading = false; });
    });
  }

  /* ============================================================
     7. LIGHTBOX
     修复：方向键在文章页（single.php）无效的问题。
     根因：bindLightboxTriggers 只从 [data-src] 元素收集图片列表，
     但 single.php 的特色图片 <a data-src> 也属于此选择器，且
     gallery-card 的 [data-src] 不存在时 lbImages 为空，moveLb 无效。
     修复方案：统一在 buildLbImages() 中收集页面所有 data-src 元素，
     确保 single 页面的特色图和文章内嵌图都进入列表。
     ============================================================ */
  var lbImages = [], lbIndex = 0;

  /**
   * 构建 lightbox 图片列表（全局，每次绑定前重建）
   * 收集顺序：① 特色图 / hero 触发器  ② 文章内容图片  ③ gallery-card 缩放按钮
   */
  function buildLbImages() {
    lbImages = [];
    var seen = {};

    function push(src, alt) {
      if (!src || seen[src]) return;
      seen[src] = true;
      lbImages.push({ src: src, alt: alt || '' });
    }

    // ① data-src 属性（含 hero 触发器、内嵌图片链接等）
    document.querySelectorAll('[data-src]').forEach(function(el) {
      push(el.getAttribute('data-src'), el.getAttribute('data-alt') || el.getAttribute('alt') || '');
    });

    // ② 文章内容中的图片（entry-content img），取 src 作为备用
    document.querySelectorAll('.entry-content img').forEach(function(img) {
      var src = img.getAttribute('data-src') || img.src;
      if (src && !src.startsWith('data:')) push(src, img.alt || '');
    });
  }

  function initLightbox() {
    buildLbImages();
    bindLightboxTriggers();

    var modal = document.getElementById('lightboxModal');
    if (!modal) return;

    var close = document.getElementById('lightboxClose');
    var prev  = document.getElementById('lightboxPrev');
    var next  = document.getElementById('lightboxNext');

    if (close) close.addEventListener('click', closeLb);
    modal.addEventListener('click', function(e) { if (e.target === modal) closeLb(); });

    if (prev) prev.addEventListener('click', function() { moveLb(-1); });
    if (next) next.addEventListener('click', function() { moveLb(1); });

    // 方向键：lightbox 打开时才响应（不与 hero slider 冲突）
    document.addEventListener('keydown', function(e) {
      if (!modal.classList.contains('is-open')) return;
      if (e.key === 'Escape')     closeLb();
      if (e.key === 'ArrowLeft')  { e.preventDefault(); moveLb(-1); }
      if (e.key === 'ArrowRight') { e.preventDefault(); moveLb(1); }
    });
  }

  function bindLightboxTriggers() {
    // 每次绑定前重建图片列表（load-more 追加新卡片后也会调用）
    buildLbImages();

    // card-zoom 按钮
    document.querySelectorAll('.card-zoom').forEach(function(btn) {
      if (btn._lb) return; btn._lb = true;
      btn.addEventListener('click', function(e) {
        e.preventDefault();
        e.stopPropagation();
        var src = btn.getAttribute('data-src');
        var idx = lbImages.findIndex(function(i) { return i.src === src; });
        openLb(idx >= 0 ? idx : 0);
      });
    });

    // 带 data-src 的链接或 .lightbox-trigger 元素（含 single.php 特色图）
    document.querySelectorAll('a[data-src], [data-src].lightbox-trigger').forEach(function(el) {
      if (el._lb) return; el._lb = true;
      el.addEventListener('click', function(e) {
        e.preventDefault();
        var src = el.getAttribute('data-src');
        var idx = lbImages.findIndex(function(i) { return i.src === src; });
        openLb(idx >= 0 ? idx : 0);
      });
    });
  }

  function openLb(idx) {
    var modal = document.getElementById('lightboxModal');
    var img   = document.getElementById('lightboxImg');
    var prev  = document.getElementById('lightboxPrev');
    var next  = document.getElementById('lightboxNext');
    if (!modal || !img || !lbImages[idx]) return;

    lbIndex = idx;
    img.src = lbImages[idx].src;
    img.alt = lbImages[idx].alt;
    modal.classList.add('is-open');
    document.body.style.overflow = 'hidden';

    // 仅一张图时隐藏导航箭头
    var single = lbImages.length <= 1;
    if (prev) prev.style.display = single ? 'none' : '';
    if (next) next.style.display = single ? 'none' : '';
  }

  function closeLb() {
    var m = document.getElementById('lightboxModal');
    if (m) m.classList.remove('is-open');
    document.body.style.overflow = '';
  }

  function moveLb(dir) {
    if (!lbImages.length) return;
    openLb(((lbIndex + dir) % lbImages.length + lbImages.length) % lbImages.length);
  }

  /* ============================================================
     8. BACK TO TOP
     ============================================================ */
  function initBackToTop() {
    var btn = document.getElementById('backToTop');
    if (!btn) return;
    window.addEventListener('scroll', function() { btn.classList.toggle('visible', window.scrollY > 400); }, { passive: true });
    btn.addEventListener('click', function(e) { e.preventDefault(); window.scrollTo({ top: 0, behavior: 'smooth' }); });
  }

  /* ============================================================
     9. CARD ANIMATIONS
     ============================================================ */
  function initCardAnimations() {
    if (!('IntersectionObserver' in window)) return;
    var obs = new IntersectionObserver(function(entries) {
      entries.forEach(function(entry) {
        if (entry.isIntersecting) { entry.target.style.animationPlayState = 'running'; obs.unobserve(entry.target); }
      });
    }, { threshold: 0.08 });
    document.querySelectorAll('.anim-fade-up').forEach(function(el) {
      el.style.animationPlayState = 'paused'; obs.observe(el);
    });
  }

})();
