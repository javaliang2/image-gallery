  </div><!-- #content -->

  <!-- Footer -->
  <footer id="colophon" class="site-footer" role="contentinfo">
    <div class="container">

      <div class="footer-top">

        <!-- Brand Column -->
        <div class="footer-brand">
          <?php if ( has_custom_logo() ) : ?>
            <?php the_custom_logo(); ?>
          <?php else : ?>
            <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="site-title" rel="home">
              <?php bloginfo( 'name' ); ?>
            </a>
          <?php endif; ?>

          <p style="margin-top:12px;">
            <?php echo wp_kses_post( get_theme_mod( 'lumina_footer_copy', bloginfo( 'description' ) ) ); ?>
          </p>

          <!-- Social links -->
          <div class="social-links" style="margin-top:20px;">
            <?php
            $socials = [
              'weibo'     => [ '微', get_theme_mod( 'lumina_social_weibo' ) ],
              'wechat'    => [ '公', get_theme_mod( 'lumina_social_wechat' ) ],
              'instagram' => [ 'Ig', get_theme_mod( 'lumina_social_instagram' ) ],
              'twitter'   => [ 'X',  get_theme_mod( 'lumina_social_twitter' ) ],
              'pinterest' => [ 'Pin', get_theme_mod( 'lumina_social_pinterest' ) ],
            ];
            foreach ( $socials as $key => [ $label, $url ] ) :
              if ( $url ) : ?>
                <a href="<?php echo esc_url( $url ); ?>" class="social-link" target="_blank" rel="noopener noreferrer" aria-label="<?php echo esc_attr( $key ); ?>">
                  <?php echo esc_html( $label ); ?>
                </a>
            <?php endif; endforeach; ?>
          </div>
        </div>

        <!-- Footer Menu Columns -->
        <?php
        $footer_menus = [
          'footer-1' => __( '导航', 'lumina-gallery' ),
          'footer-2' => __( '分类', 'lumina-gallery' ),
          'footer-3' => __( '关于', 'lumina-gallery' ),
        ];
        foreach ( $footer_menus as $location => $title ) :
          if ( has_nav_menu( $location ) ) :
        ?>
        <div class="footer-col">
          <p class="footer-col-title"><?php echo esc_html( $title ); ?></p>
          <?php
          wp_nav_menu( [
            'theme_location' => $location,
            'menu_class'     => 'footer-links',
            'container'      => false,
            'depth'          => 1,
          ] );
          ?>
        </div>
        <?php endif; endforeach; ?>

        <!-- Fallback: category list if no menus set -->
        <?php if ( ! has_nav_menu( 'footer-2' ) ) : ?>
        <div class="footer-col">
          <p class="footer-col-title"><?php esc_html_e( '分类', 'lumina-gallery' ); ?></p>
          <ul class="footer-links">
            <?php wp_list_categories( [
              'title_li'   => '',
              'number'     => 8,
              'hide_empty' => true,
              'echo'       => true,
            ] ); ?>
          </ul>
        </div>
        <?php endif; ?>

        <!-- Footer widget areas (footer-1, footer-2, footer-3) -->
        <?php foreach ( [ 'footer-1', 'footer-2', 'footer-3' ] as $_fw_id ) : ?>
          <?php if ( is_active_sidebar( $_fw_id ) ) : ?>
          <div class="footer-col">
            <?php dynamic_sidebar( $_fw_id ); ?>
          </div>
          <?php endif; ?>
        <?php endforeach; ?>

      </div><!-- .footer-top -->

      <div class="footer-bottom">
        <p class="footer-copy">
          &copy; <?php echo esc_html( gmdate( 'Y' ) ); ?>
          <a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php bloginfo( 'name' ); ?></a>.
          <?php esc_html_e( 'All Rights Reserved.', 'lumina-gallery' ); ?>
          &nbsp;·&nbsp;
          <?php /* Powered by WordPress */ ?>
          Powered by <a href="https://wordpress.org" target="_blank" rel="noopener">WordPress</a>
          &nbsp;·&nbsp;
          Theme by <strong>Lumina Gallery</strong>
        </p>

        <nav class="footer-legal">
          <a href="<?php echo esc_url( get_privacy_policy_url() ); ?>"><?php esc_html_e( '隐私政策', 'lumina-gallery' ); ?></a>
          <a href="#"><?php esc_html_e( '使用条款', 'lumina-gallery' ); ?></a>
          <a href="<?php echo esc_url( home_url( '/sitemap.xml' ) ); ?>"><?php esc_html_e( '站点地图', 'lumina-gallery' ); ?></a>
        </nav>
      </div>

    </div><!-- .container -->
  </footer><!-- #colophon -->

</div><!-- #page -->

<!-- Back to Top -->
<a href="#page" class="back-to-top" id="backToTop" aria-label="<?php esc_attr_e( '返回顶部', 'lumina-gallery' ); ?>">↑</a>

<!-- Lightbox Modal -->
<div class="modal-lightbox" id="lightboxModal" role="dialog" aria-modal="true">
  <button class="modal-close" id="lightboxClose" aria-label="<?php esc_attr_e( '关闭', 'lumina-gallery' ); ?>">✕</button>
  <button class="modal-nav prev" id="lightboxPrev" aria-label="<?php esc_attr_e( '上一张', 'lumina-gallery' ); ?>">←</button>
  <img src="" alt="" class="modal-img" id="lightboxImg">
  <button class="modal-nav next" id="lightboxNext" aria-label="<?php esc_attr_e( '下一张', 'lumina-gallery' ); ?>">→</button>
</div>

<?php wp_footer(); ?>
</body>
</html>
