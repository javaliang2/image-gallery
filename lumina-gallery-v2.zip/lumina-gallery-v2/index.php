<?php get_header(); ?>

<!-- Page Banner (only for archive/category/tag/search, not home) -->
<?php if ( ! is_front_page() && ! is_home() ) : ?>
<div class="page-banner">
  <div class="container">
    <?php if ( is_category() ) : ?>
      <p class="banner-eyebrow"><?php esc_html_e( '分类归档', 'lumina-gallery' ); ?></p>
      <h1><?php single_cat_title(); ?></h1>
      <?php if ( category_description() ) : ?><p class="banner-desc"><?php echo wp_kses_post( category_description() ); ?></p><?php endif; ?>
    <?php elseif ( is_tag() ) : ?>
      <p class="banner-eyebrow"><?php esc_html_e( '标签归档', 'lumina-gallery' ); ?></p>
      <h1><?php single_tag_title( '# ' ); ?></h1>
    <?php elseif ( is_search() ) : ?>
      <p class="banner-eyebrow"><?php esc_html_e( '搜索结果', 'lumina-gallery' ); ?></p>
      <h1><?php printf( esc_html__( '"%s"', 'lumina-gallery' ), get_search_query() ); ?></h1>
    <?php elseif ( is_archive() ) : ?>
      <p class="banner-eyebrow"><?php esc_html_e( '归档', 'lumina-gallery' ); ?></p>
      <h1><?php the_archive_title(); ?></h1>
    <?php endif; ?>
  </div>
</div>
<?php endif; ?>

<!-- Filters Bar -->
<div class="filters-bar">
  <div class="container">
    <div class="filters-inner">
      <span class="filter-label"><?php esc_html_e( '分类', 'lumina-gallery' ); ?></span>
      <?php lumina_category_pills( 'category', is_category() ? get_queried_object()->slug : '' ); ?>
      <span class="filter-divider"></span>
      <!-- 列数快速切换 -->
      <?php $active_cols = get_theme_mod( 'lumina_columns', '4' ); ?>
      <div class="col-toggle" aria-label="列数切换">
        <?php foreach ( ['2','3','4','5'] as $c ) : ?>
          <button class="col-btn<?php echo $active_cols === $c ? ' is-active' : ''; ?>"
                  data-cols="<?php echo esc_attr( $c ); ?>"
                  aria-label="<?php echo esc_attr( $c ); ?>列">
            <?php echo esc_html( $c ); ?>
          </button>
        <?php endforeach; ?>
      </div>
      <div class="view-toggle">
        <button class="view-btn is-active" data-view="grid" aria-label="网格视图">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/></svg>
        </button>
        <button class="view-btn" data-view="list" aria-label="列表视图">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/></svg>
        </button>
      </div>
    </div>
  </div>
</div>

<!-- Main Content -->
<div class="gallery-section">
  <div class="container">
    <div class="content-with-sidebar">

      <main id="primary" class="site-main">

        <?php if ( have_posts() ) : ?>

          <div class="grid-toolbar">
            <p class="results-info">
              <?php global $wp_query; printf( __( '共 <strong>%d</strong> 项', 'lumina-gallery' ), $wp_query->found_posts ); ?>
            </p>
            <select id="gallerySort" class="sort-select">
              <option value="date-desc"><?php esc_html_e( '最新发布', 'lumina-gallery' ); ?></option>
              <option value="date-asc"><?php esc_html_e( '最早发布', 'lumina-gallery' ); ?></option>
              <option value="title-asc"><?php esc_html_e( '标题 A-Z', 'lumina-gallery' ); ?></option>
            </select>
          </div>

          <div class="gallery-grid" id="galleryGrid"
               data-post-type="post"
               data-per-page="<?php echo esc_attr( get_option( 'posts_per_page' ) ); ?>"
               data-page="1">

            <?php $i = 0; while ( have_posts() ) : the_post(); $i++; ?>
              <article class="gallery-card anim-fade-up" style="--i:<?php echo $i; ?>" data-id="<?php the_ID(); ?>">
                <?php get_template_part( 'template-parts/card', 'gallery' ); ?>
              </article>
            <?php endwhile; ?>

          </div>

          <div class="pagination-wrap">
            <?php global $wp_query; if ( $wp_query->max_num_pages > 1 ) : ?>
              <button class="btn-load-more" id="loadMoreBtn"
                      data-page="1"
                      data-max="<?php echo esc_attr( $wp_query->max_num_pages ); ?>">
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 12 15 18 9"/></svg>
                <?php esc_html_e( '加载更多', 'lumina-gallery' ); ?>
              </button>
            <?php endif; ?>
            <?php lumina_pagination(); ?>
          </div>

        <?php else : ?>
          <div class="empty-state">
            <div class="empty-icon">📷</div>
            <h3><?php esc_html_e( '暂无内容', 'lumina-gallery' ); ?></h3>
            <p><?php esc_html_e( '还没有发布任何内容，请稍后再来。', 'lumina-gallery' ); ?></p>
          </div>
        <?php endif; ?>

      </main>

      <!-- Sidebar -->
      <aside class="sidebar" role="complementary">

        <?php if ( is_active_sidebar( 'sidebar-1' ) ) : ?>
          <?php dynamic_sidebar( 'sidebar-1' ); ?>
        <?php else : ?>

          <!-- 搜索 -->
          <div class="widget">
            <div class="widget-header">
              <span class="widget-icon">◎</span>
              <h3 class="widget-title"><?php esc_html_e( '搜索', 'lumina-gallery' ); ?></h3>
            </div>
            <div class="widget-body">
              <?php get_search_form(); ?>
            </div>
          </div>

          <!-- 分类 -->
          <div class="widget">
            <div class="widget-header">
              <span class="widget-icon">◆</span>
              <h3 class="widget-title"><?php esc_html_e( '分类', 'lumina-gallery' ); ?></h3>
            </div>
            <div class="widget-body" style="padding:0 18px;">
              <ul class="widget-categories">
                <?php wp_list_categories( [
                  'title_li'   => '',
                  'hide_empty' => true,
                  'show_count' => true,
                  'walker'     => new Lumina_Category_Walker(),
                ] ); ?>
              </ul>
            </div>
          </div>

          <!-- 标签云 -->
          <div class="widget">
            <div class="widget-header">
              <span class="widget-icon">◇</span>
              <h3 class="widget-title"><?php esc_html_e( '标签', 'lumina-gallery' ); ?></h3>
            </div>
            <div class="widget-body">
              <div class="widget-tagcloud">
                <?php wp_tag_cloud( [ 'number' => 28, 'unit' => 'px', 'smallest' => 11, 'largest' => 12, 'format' => 'flat', 'separator' => '' ] ); ?>
              </div>
            </div>
          </div>

        <?php endif; ?>
      </aside>

    </div>
  </div>
</div>

<?php get_footer(); ?>
