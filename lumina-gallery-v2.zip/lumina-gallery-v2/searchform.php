<form role="search" method="get" class="search-form" action="<?php echo esc_url( home_url( '/' ) ); ?>">
  <label>
    <span class="screen-reader-text"><?php esc_html_e( '搜索', 'lumina-gallery' ); ?></span>
    <input
      type="search"
      class="search-field"
      placeholder="<?php esc_attr_e( '搜索图片集、标签、分类…', 'lumina-gallery' ); ?>"
      value="<?php echo get_search_query(); ?>"
      name="s"
      autocomplete="off"
    >
  </label>
  <button type="submit" class="search-submit" aria-label="<?php esc_attr_e( '搜索', 'lumina-gallery' ); ?>">
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
      <circle cx="11" cy="11" r="8"/>
      <path d="m21 21-4.35-4.35"/>
    </svg>
  </button>
</form>
