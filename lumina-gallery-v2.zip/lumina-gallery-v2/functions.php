<?php
/**
 * Lumina Gallery — functions.php
 * Theme setup, enqueue scripts/styles, register menus, sidebars, custom post type, etc.
 */

defined( 'ABSPATH' ) || exit;

define( 'LUMINA_VERSION', '1.0.0' );
define( 'LUMINA_DIR',     get_template_directory() );
define( 'LUMINA_URI',     get_template_directory_uri() );

/* ============================================================
   1. THEME SETUP
   ============================================================ */
function lumina_setup() {
    load_theme_textdomain( 'lumina-gallery', LUMINA_DIR . '/languages' );

    add_theme_support( 'automatic-feed-links' );
    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
    add_theme_support( 'html5', [
        'search-form', 'gallery', 'caption', 'style', 'script',
    ] );
    add_theme_support( 'customize-selective-refresh-widgets' );
    add_theme_support( 'wp-block-styles' );
    add_theme_support( 'editor-styles' );
    add_theme_support( 'responsive-embeds' );

    // Custom logo
    add_theme_support( 'custom-logo', [
        'height'      => 72,
        'width'       => 240,
        'flex-height' => true,
        'flex-width'  => true,
    ] );

    // Custom image sizes
    add_image_size( 'lumina-thumb',     600,  450, true );
    add_image_size( 'lumina-medium',    900,  680, true );
    add_image_size( 'lumina-hero',     1400, 9999, false ); // 软裁剪：等比缩放，不强制裁剪高度
    add_image_size( 'lumina-square',    480,  480, true );

    // Custom header image
    add_theme_support( 'custom-header', [
        'default-image'      => '',
        'width'              => 1400,
        'height'             => 340,
        'flex-width'         => true,
        'flex-height'        => true,
        'uploads'            => true,
        'header-text'        => true,
        'default-text-color' => 'ede9f8',
    ] );

    // Navigation menus
    register_nav_menus( [
        'primary'  => __( '主导航', 'lumina-gallery' ),
        'footer-1' => __( '页脚菜单一', 'lumina-gallery' ),
        'footer-2' => __( '页脚菜单二', 'lumina-gallery' ),
        'footer-3' => __( '页脚菜单三', 'lumina-gallery' ),
        'mobile'   => __( '移动端菜单', 'lumina-gallery' ),
    ] );
}
add_action( 'after_setup_theme', 'lumina_setup' );

/* ============================================================
   2. CONTENT WIDTH
   ============================================================ */
function lumina_content_width() {
    $GLOBALS['content_width'] = apply_filters( 'lumina_content_width', 1400 );
}
add_action( 'after_setup_theme', 'lumina_content_width', 0 );

/* ============================================================
   3. ENQUEUE SCRIPTS & STYLES
   ============================================================ */
function lumina_scripts() {
    // ── Resource hints: preconnect Google Fonts (output via wp_head) ──
    // (handled by lumina_resource_hints below)

    // Google Fonts — load with display=swap, preconnect added separately
    wp_enqueue_style(
        'lumina-fonts',
        'https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,500;0,600;1,400&family=DM+Sans:opsz,wght@9..40,400;9..40,500;9..40,600&display=swap',
        [],
        null
    );

    // Main stylesheet
    wp_enqueue_style( 'lumina-style', get_stylesheet_uri(), [ 'lumina-fonts' ], LUMINA_VERSION );

    // Main JS — loaded in footer, no jQuery dependency
    wp_enqueue_script(
        'lumina-main',
        LUMINA_URI . '/js/main.js',
        [],          // no dependencies — vanilla JS only
        LUMINA_VERSION,
        [ 'strategy' => 'defer', 'in_footer' => true ]
    );

    // Pass data to JS
    wp_localize_script( 'lumina-main', 'luminaData', [
        'ajaxUrl'    => admin_url( 'admin-ajax.php' ),
        'nonce'      => wp_create_nonce( 'lumina_nonce' ),
        'loadingTxt' => __( '加载中…', 'lumina-gallery' ),
        'noMoreTxt'  => __( '已加载全部', 'lumina-gallery' ),
    ] );
}
add_action( 'wp_enqueue_scripts', 'lumina_scripts' );

/* ============================================================
   3b. RESOURCE HINTS — preconnect for Google Fonts
   ============================================================ */
function lumina_resource_hints( $hints, $relation_type ) {
    if ( 'preconnect' === $relation_type ) {
        $hints[] = [ 'href' => 'https://fonts.googleapis.com' ];
        $hints[] = [ 'href' => 'https://fonts.gstatic.com', 'crossorigin' => 'anonymous' ];
    }
    return $hints;
}
add_filter( 'wp_resource_hints', 'lumina_resource_hints', 10, 2 );

/* ============================================================
   3c. PERFORMANCE — remove unused head bloat
   ============================================================ */
// Remove jQuery from front-end (theme is vanilla JS)
add_action( 'wp_enqueue_scripts', function() {
    if ( ! is_admin() ) {
        wp_deregister_script( 'jquery' );
    }
} );

// Remove RSD link, shortlink, generator meta
remove_action( 'wp_head', 'rsd_link' );
remove_action( 'wp_head', 'wp_shortlink_wp_head' );
remove_action( 'wp_head', 'wp_generator' );
remove_action( 'wp_head', 'wlwmanifest_link' );
remove_action( 'wp_head', 'adjacent_posts_rel_link_wp_head', 10 );

// Add fetchpriority="high" to the first hero image (LCP optimisation)
add_filter( 'wp_get_attachment_image_attributes', function( $attr, $attachment, $size ) {
    static $hero_done = false;
    if ( ! $hero_done && in_array( $size, [ 'lumina-hero', 'full' ], true ) ) {
        $attr['fetchpriority'] = 'high';
        $attr['loading']       = 'eager'; // override lazy for LCP image
        $hero_done = true;
    }
    return $attr;
}, 10, 3 );

/* ============================================================
   4. REGISTER SIDEBARS / WIDGET AREAS
   ============================================================ */
function lumina_widgets_init() {
    $shared = [
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<div class="widget-header"><span class="widget-icon">◆</span><h3 class="widget-title">',
        'after_title'   => '</h3></div><div class="widget-body">',
    ];

    register_sidebar( array_merge( $shared, [
        'name'          => __( '侧边栏', 'lumina-gallery' ),
        'id'            => 'sidebar-1',
        'description'   => __( '主侧边栏小工具区域', 'lumina-gallery' ),
    ] ) );

    register_sidebar( array_merge( $shared, [
        'name'          => __( '页脚区域一', 'lumina-gallery' ),
        'id'            => 'footer-1',
        'description'   => __( '页脚第一列小工具', 'lumina-gallery' ),
    ] ) );

    register_sidebar( array_merge( $shared, [
        'name'          => __( '页脚区域二', 'lumina-gallery' ),
        'id'            => 'footer-2',
        'description'   => __( '页脚第二列小工具', 'lumina-gallery' ),
    ] ) );

    register_sidebar( array_merge( $shared, [
        'name'          => __( '页脚区域三', 'lumina-gallery' ),
        'id'            => 'footer-3',
        'description'   => __( '页脚第三列小工具', 'lumina-gallery' ),
    ] ) );

    register_sidebar( array_merge( $shared, [
        'name'          => __( '文章侧边栏', 'lumina-gallery' ),
        'id'            => 'sidebar-single',
        'description'   => __( '文章详情页专用侧边栏', 'lumina-gallery' ),
    ] ) );

}
add_action( 'widgets_init', 'lumina_widgets_init' );



/* ============================================================
   7. AJAX — LOAD MORE
   ============================================================ */
function lumina_load_more() {
    check_ajax_referer( 'lumina_nonce', 'nonce' );

    $paged       = absint( $_POST['page'] ?? 1 ) + 1;
    $category    = sanitize_text_field( $_POST['category'] ?? '' );
    $tag         = sanitize_text_field( $_POST['tag'] ?? '' );
    $post_type   = sanitize_text_field( $_POST['post_type'] ?? 'post' );
    $posts_per   = absint( $_POST['per_page'] ?? get_option( 'posts_per_page' ) );

    $args = [
        'post_type'      => $post_type,
        'post_status'    => 'publish',
        'paged'          => $paged,
        'posts_per_page' => $posts_per,
    ];

    if ( $category ) {
        $args['tax_query'][] = [
            'taxonomy' => 'category',
            'field'    => 'slug',
            'terms'    => $category,
        ];
    }

    if ( $tag ) {
        $args['tax_query'][] = [
            'taxonomy' => 'post_tag',
            'field'    => 'slug',
            'terms'    => $tag,
        ];
    }

    $query = new WP_Query( $args );

    if ( $query->have_posts() ) {
        ob_start();
        while ( $query->have_posts() ) {
            $query->the_post();
            get_template_part( 'template-parts/card', 'gallery' );
        }
        wp_reset_postdata();
        $html = ob_get_clean();

        wp_send_json_success( [
            'html'     => $html,
            'has_more' => $paged < $query->max_num_pages,
            'page'     => $paged,
        ] );
    }

    wp_send_json_error( [ 'message' => __( '没有更多内容', 'lumina-gallery' ) ] );
}
add_action( 'wp_ajax_lumina_load_more',        'lumina_load_more' );
add_action( 'wp_ajax_nopriv_lumina_load_more', 'lumina_load_more' );

/* ============================================================
   8. HELPER FUNCTIONS
   ============================================================ */


/**
 * 输出分页
 */
function lumina_pagination( $query = null ) {
    global $wp_query;
    $q = $query ?: $wp_query;

    $total   = $q->max_num_pages;
    $current = max( 1, get_query_var( 'paged' ) );

    if ( $total <= 1 ) return;

    $args = [
        'base'      => str_replace( PHP_INT_MAX, '%#%', esc_url( get_pagenum_link( PHP_INT_MAX ) ) ),
        'format'    => '?paged=%#%',
        'current'   => $current,
        'total'     => $total,
        'prev_text' => '← ' . __( '上一页', 'lumina-gallery' ),
        'next_text' => __( '下一页', 'lumina-gallery' ) . ' →',
        'type'      => 'array',
        'mid_size'  => 2,
    ];

    $pages = paginate_links( $args );
    if ( ! $pages ) return;

    echo '<nav class="wp-pagination" aria-label="' . esc_attr__( '页面导航', 'lumina-gallery' ) . '">';
    foreach ( $pages as $page ) echo $page;
    echo '</nav>';
}

/**
 * 读取分类过滤器 pills
 */
function lumina_category_pills( $taxonomy = 'category', $current = '' ) {
    $terms = get_terms( [ 'taxonomy' => $taxonomy, 'hide_empty' => true ] );
    if ( is_wp_error( $terms ) || empty( $terms ) ) return;

    $queried_post_type = get_query_var( 'post_type' ) ?: 'post';
    if ( is_array( $queried_post_type ) ) $queried_post_type = reset( $queried_post_type );
    $all_url = get_post_type_archive_link( $queried_post_type ) ?: home_url( '/' );
    printf(
        '<a href="%s" class="filter-pill%s">%s</a>',
        esc_url( $all_url ),
        ! $current ? ' is-active' : '',
        esc_html__( '全部', 'lumina-gallery' )
    );

    foreach ( $terms as $term ) {
        printf(
            '<a href="%s" class="filter-pill%s">%s</a>',
            esc_url( get_term_link( $term ) ),
            ( $current === $term->slug ) ? ' is-active' : '',
            esc_html( $term->name )
        );
    }
}

/**
 * 主题定制器选项
 */
function lumina_customize_register( $wp_customize ) {

    /* ── 社交媒体 ── */
    $wp_customize->add_section( 'lumina_social', [
        'title'    => __( '社交媒体', 'lumina-gallery' ),
        'priority' => 130,
    ] );

    $socials = [ 'weibo' => '微博', 'wechat' => '微信', 'instagram' => 'Instagram', 'twitter' => 'Twitter/X', 'pinterest' => 'Pinterest' ];
    foreach ( $socials as $id => $label ) {
        $wp_customize->add_setting( "lumina_social_{$id}", [ 'default' => '', 'sanitize_callback' => 'esc_url_raw' ] );
        $wp_customize->add_control( "lumina_social_{$id}", [
            'label'   => $label . ' URL',
            'section' => 'lumina_social',
            'type'    => 'url',
        ] );
    }

    /* ── 页脚版权文字 ── */
    $wp_customize->add_setting( 'lumina_footer_copy', [ 'default' => '', 'sanitize_callback' => 'wp_kses_post' ] );
    $wp_customize->add_control( 'lumina_footer_copy', [
        'label'   => __( '页脚版权文字', 'lumina-gallery' ),
        'section' => 'title_tagline',
        'type'    => 'textarea',
    ] );

    /* ── 每页图片数量 ── */
    $wp_customize->add_setting( 'lumina_per_page', [ 'default' => 12, 'sanitize_callback' => 'absint' ] );
    $wp_customize->add_control( 'lumina_per_page', [
        'label'   => __( '每页显示数量', 'lumina-gallery' ),
        'section' => 'title_tagline',
        'type'    => 'number',
    ] );

    /* ── 桌面列数 ── */
    $wp_customize->add_setting( 'lumina_columns', [
        'default'           => '4',
        'sanitize_callback' => function( $val ) {
            return in_array( $val, [ '2', '3', '4', '5' ], true ) ? $val : '4';
        },
        'transport' => 'postMessage',
    ] );
    $wp_customize->add_control( 'lumina_columns', [
        'label'   => __( '桌面列数（宽屏默认列数）', 'lumina-gallery' ),
        'section' => 'title_tagline',
        'type'    => 'select',
        'choices' => [
            '2' => __( '2 列', 'lumina-gallery' ),
            '3' => __( '3 列', 'lumina-gallery' ),
            '4' => __( '4 列（默认）', 'lumina-gallery' ),
            '5' => __( '5 列', 'lumina-gallery' ),
        ],
    ] );

    /* ──────────────────────────────────────────────────────────
       颜色设置面板
       ────────────────────────────────────────────────────────── */
    $wp_customize->add_section( 'lumina_colors', [
        'title'    => __( '主题颜色', 'lumina-gallery' ),
        'priority' => 40,
    ] );

    $color_settings = [
        'lumina_color_bg' => [
            'label'   => __( '页面背景色', 'lumina-gallery' ),
            'default' => '#f6f5f2',
        ],
        'lumina_color_surface' => [
            'label'   => __( '卡片/面板背景色', 'lumina-gallery' ),
            'default' => '#ffffff',
        ],
        'lumina_color_accent' => [
            'label'   => __( '主强调色', 'lumina-gallery' ),
            'default' => '#c9a96e',
        ],
        'lumina_color_accent_alt' => [
            'label'   => __( '次强调色', 'lumina-gallery' ),
            'default' => '#b5925a',
        ],
        'lumina_color_text' => [
            'label'   => __( '正文文字色', 'lumina-gallery' ),
            'default' => '#1c1c1a',
        ],
        'lumina_color_text_muted' => [
            'label'   => __( '次级文字色', 'lumina-gallery' ),
            'default' => '#6b6b68',
        ],
        'lumina_color_border' => [
            'label'   => __( '边框色', 'lumina-gallery' ),
            'default' => '#e0deda',
        ],
        'lumina_color_dark' => [
            'label'   => __( '顶栏/页脚背景色', 'lumina-gallery' ),
            'default' => '#1c1c1a',
        ],
    ];

    foreach ( $color_settings as $id => $cfg ) {
        $wp_customize->add_setting( $id, [
            'default'           => $cfg['default'],
            'sanitize_callback' => 'sanitize_hex_color',
            'transport'         => 'postMessage', // 实时预览无需刷新
        ] );
        $wp_customize->add_control(
            new WP_Customize_Color_Control( $wp_customize, $id, [
                'label'   => $cfg['label'],
                'section' => 'lumina_colors',
            ] )
        );
    }
}
add_action( 'customize_register', 'lumina_customize_register' );

/**
 * 将定制器颜色值输出为 CSS 自定义属性（覆盖 style.css 中的默认值）
 * 挂载到 wp_head，优先级 99 确保在主样式表之后输出。
 */
function lumina_customizer_inline_css() {
    $defaults = [
        'lumina_color_bg'         => '#f6f5f2',
        'lumina_color_surface'    => '#ffffff',
        'lumina_color_accent'     => '#c9a96e',
        'lumina_color_accent_alt' => '#b5925a',
        'lumina_color_text'       => '#1c1c1a',
        'lumina_color_text_muted' => '#6b6b68',
        'lumina_color_border'     => '#e0deda',
        'lumina_color_dark'       => '#1c1c1a',
    ];

    $map = [
        'lumina_color_bg'         => '--lumina-bg',
        'lumina_color_surface'    => '--lumina-surface',
        'lumina_color_accent'     => '--lumina-accent',
        'lumina_color_accent_alt' => '--lumina-accent-alt',
        'lumina_color_text'       => '--lumina-text',
        'lumina_color_text_muted' => '--lumina-text-muted',
        'lumina_color_border'     => '--lumina-border',
        'lumina_color_dark'       => '--lumina-dark',
    ];

    $overrides = '';
    foreach ( $map as $mod_key => $css_var ) {
        $value = get_theme_mod( $mod_key, $defaults[ $mod_key ] );
        if ( $value && $value !== $defaults[ $mod_key ] ) {
            // 只有用户改变了默认值时才输出，减少冗余 CSS
            $overrides .= sprintf( "  %s: %s;\n", esc_attr( $css_var ), sanitize_hex_color( $value ) );
        }
    }

    // Columns
    $cols = get_theme_mod( 'lumina_columns', '4' );
    $cols = in_array( $cols, [ '2', '3', '4', '5' ] ) ? $cols : '4';
    $min_w_map = [ '2' => '480px', '3' => '320px', '4' => '240px', '5' => '190px' ];
    $min_w = $min_w_map[ $cols ];
    $overrides .= "  --lumina-col-min: {$min_w};\n";
    $overrides .= "  --lumina-cols: {$cols};\n";

    if ( $overrides ) {
        printf( "<style id=\"lumina-customizer-colors\">\n:root {\n%s}\n</style>\n", $overrides );
    }
}
add_action( 'wp_head', 'lumina_customizer_inline_css', 99 );

/**
 * 定制器实时预览（postMessage 传输）
 * 通过 JS 直接更新 CSS 变量，无需页面刷新。
 */
function lumina_customize_preview_js() {
    ?>
    <script>
    (function($) {
        // 实时预览：列数变化
        wp.customize('lumina_columns', function(value) {
            value.bind(function(cols) {
                var minW = { '2':'480px', '3':'320px', '4':'240px', '5':'200px' }[cols] || '240px';
                document.getElementById('galleryGrid') &&
                    (document.getElementById('galleryGrid').style.gridTemplateColumns =
                        'repeat(auto-fill, minmax(' + minW + ', 1fr))');
                document.querySelectorAll('.col-btn').forEach(function(b){
                    b.classList.toggle('is-active', b.getAttribute('data-cols') === cols);
                });
            });
        });
        var colorMap = {
            'lumina_color_bg':         '--lumina-bg',
            'lumina_color_surface':    '--lumina-surface',
            'lumina_color_accent':     '--lumina-accent',
            'lumina_color_accent_alt': '--lumina-accent-alt',
            'lumina_color_text':       '--lumina-text',
            'lumina_color_text_muted': '--lumina-text-muted',
            'lumina_color_border':     '--lumina-border',
            'lumina_color_dark':       '--lumina-dark',
        };
        Object.keys(colorMap).forEach(function(settingId) {
            wp.customize(settingId, function(value) {
                value.bind(function(newval) {
                    document.documentElement.style.setProperty(colorMap[settingId], newval);
                });
            });
        });
    })(jQuery);
    </script>
    <?php
}
add_action( 'customize_preview_init', function() {
    add_action( 'wp_footer', 'lumina_customize_preview_js', 99 );
} );

/* ============================================================
   9. EXCERPT LENGTH
   ============================================================ */
add_filter( 'excerpt_length', fn() => 28, 999 );
add_filter( 'excerpt_more',   fn() => '…' );

/* ============================================================
   10. REMOVE WP EMOJI (PERF)
   ============================================================ */
remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
remove_action( 'wp_print_styles', 'print_emoji_styles' );

/* ============================================================
   12. DISABLE COMMENTS GLOBALLY
   ============================================================ */
// Close comments on all posts
add_filter( 'comments_open',        '__return_false', 20, 2 );
add_filter( 'pings_open',           '__return_false', 20, 2 );
// Hide existing comments
add_filter( 'comments_array',       '__return_empty_array', 10, 2 );
// Remove comments from admin menu
add_action( 'admin_menu', function() {
    remove_menu_page( 'edit-comments.php' );
} );
// Remove comments from admin bar
add_action( 'wp_before_admin_bar_render', function() {
    global $wp_admin_bar;
    $wp_admin_bar->remove_menu( 'comments' );
} );

/* ============================================================
   11. CATEGORY WALKER
   ============================================================ */
class Lumina_Category_Walker extends Walker_Category {
    public function start_el( &$output, $data_object, $depth = 0, $args = [], $current_object_id = 0 ) {
        $url    = get_category_link( $data_object->term_id );
        $name   = esc_html( $data_object->name );
        $count  = $data_object->count;
        $active = is_category( $data_object->term_id ) ? ' class="current"' : '';
        $output .= "<li><a href=\"{$url}\"{$active}>{$name}<span class=\"count\">{$count}</span></a></li>";
    }
}
