<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo( 'charset' ); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="profile" href="https://gmpg.org/xfn/11">
  <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<div id="page" class="site">

  <!-- Top Bar -->
  <div class="site-topbar">
    <div class="container">
      <span>📸 <?php bloginfo( 'description' ); ?></span>
      <div style="display:flex;gap:16px;align-items:center;">
        <?php if ( get_theme_mod( 'lumina_social_weibo' ) ) : ?>
          <a href="<?php echo esc_url( get_theme_mod( 'lumina_social_weibo' ) ); ?>" target="_blank" rel="noopener">微博</a>
        <?php endif; ?>
        <?php if ( get_theme_mod( 'lumina_social_wechat' ) ) : ?>
          <a href="<?php echo esc_url( get_theme_mod( 'lumina_social_wechat' ) ); ?>" target="_blank" rel="noopener">微信</a>
        <?php endif; ?>
        <?php if ( is_user_logged_in() ) : ?>
          <a href="<?php echo esc_url( admin_url() ); ?>">后台管理</a>
        <?php else : ?>
          <a href="<?php echo esc_url( wp_login_url( get_permalink() ) ); ?>">登录</a>
        <?php endif; ?>
      </div>
    </div>
  </div>

  <!-- Hero Slider (shown only on front page) -->
  <?php if ( is_front_page() || is_home() ) : ?>
  <?php
  $slider_posts = get_posts( [
    'numberposts' => 5,
    'post_status' => 'publish',
    'meta_key'    => '_thumbnail_id',
    'orderby'     => 'date',
    'order'       => 'DESC',
  ] );
  ?>
  <div class="hero-slider" id="heroSlider"
       data-autoplay="5000"
       data-count="<?php echo count($slider_posts); ?>">

    <?php if ( $slider_posts ) : ?>

      <div class="hero-slides" id="heroSlides">
        <?php foreach ( $slider_posts as $i => $sp ) :
          $img_url = get_the_post_thumbnail_url( $sp->ID, 'lumina-hero' );
          $cats    = get_the_category( $sp->ID );
          $cat     = $cats ? $cats[0] : null;
          $excerpt = get_the_excerpt( $sp );
        ?>
        <div class="hero-slide<?php echo $i === 0 ? ' is-active' : ''; ?>" data-index="<?php echo $i; ?>">
          <img src="<?php echo esc_url( $img_url ); ?>" alt="<?php echo esc_attr( $sp->post_title ); ?>" <?php echo $i > 0 ? 'loading="lazy"' : ''; ?>>
          <div class="hero-slide-overlay">
            <div class="hero-slide-content">
              <?php if ( $cat ) : ?>
                <span class="hero-slide-cat"><?php echo esc_html( $cat->name ); ?></span>
              <?php endif; ?>
              <h2 class="hero-slide-title"><?php echo esc_html( $sp->post_title ); ?></h2>
              <?php if ( $excerpt ) : ?>
                <p class="hero-slide-excerpt"><?php echo esc_html( wp_trim_words( $excerpt, 18 ) ); ?></p>
              <?php endif; ?>
              <a href="<?php echo esc_url( get_permalink( $sp->ID ) ); ?>" class="hero-slide-btn">
                <?php esc_html_e( '查看详情', 'lumina-gallery' ); ?>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
              </a>
            </div>
          </div>
        </div>
        <?php endforeach; ?>
      </div>

      <button class="hero-arrow prev" id="heroPrev" aria-label="上一张">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="15 18 9 12 15 6"/></svg>
      </button>
      <button class="hero-arrow next" id="heroNext" aria-label="下一张">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="9 18 15 12 9 6"/></svg>
      </button>

      <div class="hero-dots" id="heroDots">
        <?php for ( $d = 0; $d < count($slider_posts); $d++ ) : ?>
          <button class="hero-dot<?php echo $d === 0 ? ' is-active' : ''; ?>" data-index="<?php echo $d; ?>" aria-label="跳转到第<?php echo $d+1; ?>张"></button>
        <?php endfor; ?>
      </div>

      <?php if ( count($slider_posts) > 1 ) : ?>
      <div class="hero-thumbs" id="heroThumbs">
        <?php foreach ( $slider_posts as $i => $sp ) :
          $t = get_the_post_thumbnail_url( $sp->ID, 'lumina-square' );
        ?>
          <div class="hero-thumb<?php echo $i === 0 ? ' is-active' : ''; ?>" data-index="<?php echo $i; ?>">
            <img src="<?php echo esc_url( $t ); ?>" alt="" loading="lazy">
          </div>
        <?php endforeach; ?>
      </div>
      <?php endif; ?>

      <div class="hero-progress" id="heroProgress"></div>

    <?php else : ?>
      <div class="hero-placeholder">
        <svg width="56" height="56" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.2"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>
        <p><?php esc_html_e( '发布带封面图的文章即可显示画廊', 'lumina-gallery' ); ?></p>
      </div>
    <?php endif; ?>

  </div>
  <?php wp_reset_postdata(); ?>
  <?php endif; ?>

  <!-- Header -->
  <header id="masthead" class="site-header" role="banner">
    <div class="container">
      <div class="header-inner">

        <!-- Branding -->
        <div class="site-branding">
          <?php if ( has_custom_logo() ) : ?>
            <div class="site-logo"><?php the_custom_logo(); ?></div>
          <?php else : ?>
            <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="site-title" rel="home">
              <?php
                $parts = preg_split( '/(?<=.)/', get_bloginfo( 'name' ), 2 );
                echo esc_html( $parts[0] ?? '' );
                echo '<span>' . esc_html( substr( get_bloginfo( 'name' ), 1 ) ) . '</span>';
              ?>
            </a>
          <?php endif; ?>
        </div>

        <!-- Primary Navigation (desktop) -->
        <nav id="site-navigation" class="main-navigation" role="navigation"
             aria-label="<?php esc_attr_e( '主菜单', 'lumina-gallery' ); ?>">
          <?php
          wp_nav_menu( [
            'theme_location' => 'primary',
            'menu_id'        => 'primary-menu',
            'menu_class'     => 'nav-menu',
            'container'      => false,
            'fallback_cb'    => function() {
              echo '<ul class="nav-menu">';
              wp_list_pages( [ 'title_li' => '', 'echo' => 1 ] );
              echo '</ul>';
            },
          ] );
          ?>
        </nav>

        <!-- Header Actions -->
        <div class="header-actions">
          <button class="btn-search" id="searchToggle" aria-label="<?php esc_attr_e( '搜索', 'lumina-gallery' ); ?>">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
            <span><?php esc_html_e( '搜索', 'lumina-gallery' ); ?></span>
          </button>

          <!-- Hamburger (mobile only) -->
          <button class="menu-toggle" id="menuToggle"
                  aria-controls="mobile-menu-panel"
                  aria-expanded="false"
                  aria-label="<?php esc_attr_e( '打开菜单', 'lumina-gallery' ); ?>">
            <span class="bar"></span>
            <span class="bar"></span>
            <span class="bar"></span>
          </button>
        </div>

      </div><!-- .header-inner -->
    </div><!-- .container -->
  </header><!-- #masthead -->

  <!-- ═══════════════════════════════════════════════════════
       MOBILE MENU PANEL (slide-in drawer)
       独立于桌面菜单，完整支持二级菜单手风琴展开
       ═══════════════════════════════════════════════════════ -->
  <!-- Backdrop -->
  <div class="mobile-menu-backdrop" id="mobileMenuBackdrop" aria-hidden="true"></div>

  <div class="mobile-menu-panel" id="mobileMenuPanel" role="dialog"
       aria-modal="true" aria-label="<?php esc_attr_e( '移动端菜单', 'lumina-gallery' ); ?>"
       aria-hidden="true">

    <!-- Panel Header -->
    <div class="mm-header">
      <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="mm-logo">
        <?php
          $parts = preg_split( '/(?<=.)/', get_bloginfo( 'name' ), 2 );
          echo esc_html( $parts[0] ?? '' );
          echo '<span>' . esc_html( substr( get_bloginfo( 'name' ), 1 ) ) . '</span>';
        ?>
      </a>
      <button class="mm-close" id="mobileMenuClose" aria-label="<?php esc_attr_e( '关闭菜单', 'lumina-gallery' ); ?>">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
        </svg>
      </button>
    </div>

    <!-- Search shortcut -->
    <div class="mm-search">
      <button class="mm-search-btn" id="mmSearchBtn">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
        <?php esc_html_e( '搜索文章…', 'lumina-gallery' ); ?>
      </button>
    </div>

    <!-- Nav: rendered with Walker that injects accordion toggle buttons -->
    <nav class="mm-nav" aria-label="<?php esc_attr_e( '移动端主菜单', 'lumina-gallery' ); ?>">
      <?php
      // Walker: adds <button class="mm-sub-toggle"> before each sub-menu
      class Lumina_Mobile_Walker extends Walker_Nav_Menu {

        public function start_el( &$output, $data_object, $depth = 0, $args = null, $current_object_id = 0 ) {
          $item = $data_object;
          $indent = str_repeat( "\t", $depth );
          $classes = empty( $item->classes ) ? [] : (array) $item->classes;
          $classes[] = 'mm-item';
          if ( in_array( 'menu-item-has-children', $classes, true ) ) {
            $classes[] = 'has-sub';
          }
          $class_names = implode( ' ', array_filter( array_map( 'esc_attr', $classes ) ) );
          $output .= $indent . '<li class="' . $class_names . '" id="mm-item-' . $item->ID . '">';

          $atts = [];
          $atts['href']   = ! empty( $item->url )    ? $item->url    : '#';
          $atts['title']  = ! empty( $item->attr_title ) ? $item->attr_title : '';
          $atts['target'] = ! empty( $item->target )  ? $item->target : '';
          $atts['rel']    = ! empty( $item->xfn )     ? $item->xfn    : '';
          $atts['class']  = 'mm-link';
          if ( in_array( 'current-menu-item', $classes, true ) ) {
            $atts['class'] .= ' is-current';
          }
          $atts_str = '';
          foreach ( $atts as $k => $v ) {
            if ( $v ) $atts_str .= ' ' . $k . '="' . esc_attr( $v ) . '"';
          }
          $output .= '<a' . $atts_str . '>' . esc_html( $item->title ) . '</a>';

          // Inject toggle button for items with children
          if ( in_array( 'menu-item-has-children', (array) $item->classes, true ) ) {
            $output .= '<button class="mm-sub-toggle" aria-expanded="false" aria-label="' . esc_attr__( '展开子菜单', 'lumina-gallery' ) . '">'
              . '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="6 9 12 15 18 9"/></svg>'
              . '</button>';
          }
        }

        public function end_el( &$output, $data_object, $depth = 0, $args = null ) {
          $output .= "</li>\n";
        }

        public function start_lvl( &$output, $depth = 0, $args = null ) {
          $output .= '<ul class="mm-sub-menu" hidden>';
        }

        public function end_lvl( &$output, $depth = 0, $args = null ) {
          $output .= '</ul>';
        }
      }

      wp_nav_menu( [
        'theme_location' => 'primary',
        'menu_class'     => 'mm-menu',
        'container'      => false,
        'walker'         => new Lumina_Mobile_Walker(),
        'fallback_cb'    => function() {
          echo '<ul class="mm-menu">';
          wp_list_pages( [ 'title_li' => '', 'echo' => 1 ] );
          echo '</ul>';
        },
      ] );
      ?>
    </nav>

    <!-- Panel Footer: social / login -->
    <div class="mm-footer">
      <div class="mm-social">
        <?php if ( get_theme_mod( 'lumina_social_weibo' ) ) : ?>
          <a href="<?php echo esc_url( get_theme_mod( 'lumina_social_weibo' ) ); ?>" target="_blank" rel="noopener" class="mm-social-link">微博</a>
        <?php endif; ?>
        <?php if ( get_theme_mod( 'lumina_social_wechat' ) ) : ?>
          <a href="<?php echo esc_url( get_theme_mod( 'lumina_social_wechat' ) ); ?>" target="_blank" rel="noopener" class="mm-social-link">微信</a>
        <?php endif; ?>
      </div>
      <div class="mm-user">
        <?php if ( is_user_logged_in() ) : ?>
          <a href="<?php echo esc_url( admin_url() ); ?>" class="mm-user-link">后台管理</a>
        <?php else : ?>
          <a href="<?php echo esc_url( wp_login_url( get_permalink() ) ); ?>" class="mm-user-link">登录</a>
        <?php endif; ?>
      </div>
    </div>

  </div><!-- .mobile-menu-panel -->

  <!-- Search Overlay -->
  <div class="search-overlay" id="searchOverlay" role="dialog" aria-modal="true" aria-label="<?php esc_attr_e( '搜索', 'lumina-gallery' ); ?>">
    <button class="search-close" id="searchClose" aria-label="<?php esc_attr_e( '关闭搜索', 'lumina-gallery' ); ?>">✕</button>
    <?php get_search_form(); ?>
  </div>

  <div id="content" class="site-content">
