<?php get_header(); ?>

<?php while ( have_posts() ) : the_post(); ?>

<div class="single-gallery">
  <div class="container">

    <?php
    // 判断是否有侧边栏内容，有则启用两栏布局
    $has_sidebar = is_active_sidebar( 'sidebar-single' ) || is_active_sidebar( 'sidebar-1' );
    $layout_class = $has_sidebar ? 'content-with-sidebar' : 'container--narrow-inner';
    ?>

    <div class="<?php echo esc_attr( $layout_class ); ?>">

      <!-- 主内容区 -->
      <div class="single-main">

        <!-- Breadcrumb -->
        <nav class="single-breadcrumb" aria-label="面包屑">
          <a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php bloginfo( 'name' ); ?></a>
          <span class="bc-sep">›</span>
          <?php
          $cats = get_the_category();
          if ( $cats ) :
            echo '<a href="' . esc_url( get_category_link( $cats[0]->term_id ) ) . '">' . esc_html( $cats[0]->name ) . '</a>';
            echo '<span class="bc-sep">›</span>';
          endif;
          ?>
          <span><?php the_title(); ?></span>
        </nav>

        <!-- Post Header -->
        <header class="entry-header">
          <?php if ( $cats ) : ?>
            <p class="entry-cat">
              <a href="<?php echo esc_url( get_category_link( $cats[0]->term_id ) ); ?>"><?php echo esc_html( $cats[0]->name ); ?></a>
            </p>
          <?php endif; ?>

          <h1 class="entry-title"><?php the_title(); ?></h1>

          <div class="entry-meta">
            <span class="entry-author">
              <?php echo get_avatar( get_the_author_meta( 'ID' ), 22, '', '', [ 'style' => 'border-radius:50%;vertical-align:middle;' ] ); ?>
              <?php the_author(); ?>
            </span>
            <span class="entry-meta-sep">·</span>
            <time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>"><?php echo esc_html( get_the_date() ); ?></time>
            <?php
            $read_time = max( 1, (int) ceil( str_word_count( strip_tags( get_the_content() ) ) / 200 ) );
            ?>
            <span class="entry-meta-sep">·</span>
            <span>约 <?php echo $read_time; ?> 分钟阅读</span>
          </div>
        </header>

        <!-- Hero Image — 点击可放大，显示原图比例（保留顶部裁剪底部） -->
        <?php if ( has_post_thumbnail() ) :
          $full_url   = get_the_post_thumbnail_url( get_the_ID(), 'full' );
          $hero_url   = get_the_post_thumbnail_url( get_the_ID(), 'lumina-hero' );
          $thumb_meta = wp_get_attachment_metadata( get_post_thumbnail_id() );
          // 优先原图宽高，回退 lumina-hero 尺寸
          $orig_w = $thumb_meta['width']  ?? 1400;
          $orig_h = $thumb_meta['height'] ?? 900;
          $aspect = $orig_h > 0 ? round( $orig_h / $orig_w * 100, 4 ) : 60;
          // 限制最大显示高度对应的宽高比（避免竖图占满全屏）
          $max_aspect = 75; // 4:3
          $display_aspect = min( $aspect, $max_aspect );
        ?>
        <div class="gallery-hero-img">
          <a href="<?php echo esc_url( $full_url ); ?>"
             class="lightbox-trigger"
             data-src="<?php echo esc_url( $full_url ); ?>"
             data-alt="<?php the_title_attribute(); ?>">
            <!-- 用 padding-top 撑出原始比例容器，object-position:top 保留顶部 -->
            <div class="hero-img-ratio" style="padding-top:<?php echo esc_attr( $display_aspect ); ?>%;">
              <?php the_post_thumbnail( 'lumina-hero', [
                'alt'   => get_the_title(),
                'style' => 'position:absolute;inset:0;width:100%;height:100%;object-fit:cover;object-position:top center;',
              ] ); ?>
            </div>
          </a>
          <span class="hero-img-hint">点击查看原图</span>
        </div>
        <?php endif; ?>

        <!-- Post Content -->
        <div class="entry-content">
          <?php the_content(); ?>
        </div>

        <!-- Tags -->
        <?php $post_tags = get_the_tags(); if ( $post_tags ) : ?>
        <div class="post-tags-list">
          <span class="tags-label"><?php esc_html_e( '标签', 'lumina-gallery' ); ?></span>
          <?php foreach ( $post_tags as $t ) : ?>
            <a href="<?php echo esc_url( get_tag_link( $t ) ); ?>" class="post-tag">#<?php echo esc_html( $t->name ); ?></a>
          <?php endforeach; ?>
        </div>
        <?php endif; ?>

        <!-- Post Navigation -->
        <?php
        $prev_post = get_previous_post();
        $next_post = get_next_post();
        if ( $prev_post || $next_post ) : ?>
        <div class="post-nav">
          <?php if ( $prev_post ) : ?>
          <a href="<?php echo esc_url( get_permalink( $prev_post ) ); ?>" class="post-nav-item">
            <p class="post-nav-label">← <?php esc_html_e( '上一篇', 'lumina-gallery' ); ?></p>
            <p class="post-nav-title"><?php echo esc_html( get_the_title( $prev_post ) ); ?></p>
          </a>
          <?php else : ?><div></div><?php endif; ?>
          <?php if ( $next_post ) : ?>
          <a href="<?php echo esc_url( get_permalink( $next_post ) ); ?>" class="post-nav-item" style="text-align:right;">
            <p class="post-nav-label"><?php esc_html_e( '下一篇', 'lumina-gallery' ); ?> →</p>
            <p class="post-nav-title"><?php echo esc_html( get_the_title( $next_post ) ); ?></p>
          </a>
          <?php endif; ?>
        </div>
        <?php endif; ?>

      </div><!-- .single-main -->

      <!-- 侧边栏 -->
      <?php if ( $has_sidebar ) : ?>
      <aside class="sidebar" role="complementary" aria-label="侧边栏">
        <?php
        if ( is_active_sidebar( 'sidebar-single' ) ) {
            dynamic_sidebar( 'sidebar-single' );
        } elseif ( is_active_sidebar( 'sidebar-1' ) ) {
            dynamic_sidebar( 'sidebar-1' );
        }
        ?>
      </aside>
      <?php endif; ?>

    </div><!-- .content-with-sidebar / .container--narrow-inner -->

  </div><!-- .container -->
</div><!-- .single-gallery -->

<?php endwhile; ?>
<?php get_footer(); ?>
